<?php	
	require_once 'core/init.php';

	$db = DB::getInstance();
	$input = new Input();
	$volunteers = new Volunteers();


	if($input->get("requestId") == "getAllVolunteers") {
		print_r(json_encode($volunteers->getAllVolunteers()));

	} else if($input->get("requestId") == "getVolunteer") {
		print_r(json_encode($volunteers->getVolunteer()));
	}

// print_r(json_encode($volunteers->getAllVolunteers()));
	/*if(isset($_GET["requestId"]) == "getAllVolunteers") {
		$query = "SELECT * FROM volunteers" ;
		$result = mysqli_query($conn,$query);

		// print_r($result);
		while($row = mysqli_fetch_array($result)) {

			$dataArray[] = array(
				"id" => $row["volunteer_id"],
				"full_name" => $row["full_name"],
				"blood_type" => $row["blood_type"],
				"profession" => $row["profession"],
				"age" => $row["age"],
				"location" => array(
					"lat" => $row["latitude"],
					"lng" => $row["longitude"]
				)
			);

		}

		print_r(json_encode($dataArray));
	}*/

	


?>