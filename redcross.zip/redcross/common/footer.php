<footer class="sticky-footer">
<div class="container">
	<div class="text-center">
	   <small>Copyright © Redcross QC 2018</small>
	</div>
</div>
</footer>